/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas;

/**
 *
 * @author amd zra
 */
public class Mahasiswa {
    
    public static void main(String[] args) {
      String nama = "Ahmad Zidny Rofi 'Amir";
      String kelas = "4A";
      String nim = "17090132";
        System.out.println("Nama : "+nama);
        System.out.println("Kelas : "+kelas);
        System.out.println("Nim : "+nim);
        
    }
    
}
